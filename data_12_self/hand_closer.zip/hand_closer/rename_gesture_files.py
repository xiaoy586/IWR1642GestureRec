import os
import shutil

# 需要重命名的文件编号范围
START = 101
END = 150

for old_num in range(START, END + 1):
    old_name = f"gesture_{old_num}.csv"
    new_num = old_num - 100
    new_name = f"gesture_{new_num}.csv"
    
    # 检查源文件是否存在
    if not os.path.exists(old_name):
        print(f"警告: {old_name} 不存在，已跳过")
        continue
    
    # 检查目标文件是否已存在，避免覆盖
    if os.path.exists(new_name):
        print(f"警告: {new_name} 已存在，跳过重命名 {old_name}")
        continue
    
    # 执行重命名
    shutil.move(old_name, new_name)
    print(f"已重命名: {old_name} -> {new_name}")

print("重命名操作完成！")